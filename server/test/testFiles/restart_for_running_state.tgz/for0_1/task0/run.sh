sleep 10
pwd > output.txt