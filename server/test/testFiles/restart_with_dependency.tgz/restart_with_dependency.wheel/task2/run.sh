pwd
exit 0